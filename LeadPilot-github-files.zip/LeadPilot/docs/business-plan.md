# LeadPilot – Üzleti terv

## 1. Termékkoncepció

**LeadPilot – Smart Follow-up System for Small Businesses**

A LeadPilot egy egyszerű, kis szolgáltató vállalkozásoknak szánt utánkövető rendszer. Elsődleges feladata, hogy segítsen nyomon követni az érdeklődőket és a kiküldött ajánlatokat, valamint jelezze, mikor szükséges újra felvenni a kapcsolatot egy potenciális ügyféllel.

Nem általános CRM-et kívánunk építeni. A termék egy jól körülhatárolt problémára koncentrál: az elfelejtett érdeklődőkre és az elmaradt ajánlat-utánkövetésre.

## 2. Célpiac és célközönség

- **Kezdő piac:** Magyarország.
- **Elsődleges célközönség-javaslat:** 1–10 fős szolgáltató vállalkozások.
- **Elsőként vizsgálandó szegmens:** klímaszerelők és klímatelepítők.
- **Később vizsgálható szegmensek:** villanyszerelők, vízvezeték-szerelők, festők és nyílászáró-beépítők.

A klímaszerelői szegmens egyelőre hipotézis, nem validált piaci döntés. A célcsoport kiválasztását legalább öt potenciális ügyféllel folytatott beszélgetéssel kell ellenőrizni.

## 3. Ügyfélprobléma

Egy kisebb szolgáltató vállalkozás naponta több érdeklődést és ajánlatkérést kezelhet. Az információk telefonban, e-mailben, papíron vagy táblázatokban szétszóródhatnak. Emiatt egy korábbi érdeklődő vagy kiküldött ajánlat könnyen kieshet a vállalkozó figyelméből.

A LeadPilot értékajánlata: egy helyen láthatóvá tenni, kivel és mikor szükséges újra kapcsolatba lépni.

## 4. Javasolt felhasználói folyamat

1. **Érdeklődő rögzítése:** név, elérhetőség és kért szolgáltatás.
2. **Ajánlat rögzítése:** az ajánlat elküldésének dátuma, opcionálisan az ajánlat értéke.
3. **Emlékeztető:** például három nap válasz nélkül elteltével a rendszer jelezze a vállalkozónak a következő teendőt.
4. **Utánkövetés:** a vállalkozó telefonon vagy e-mailben felveszi a kapcsolatot az ügyféllel.
5. **Eredmény rögzítése:** például megnyert, elvesztett vagy folyamatban lévő ajánlat.
6. **Dashboard:** nyitott ajánlatok, aznapi teendők, várakozó ajánlati érték és ajánlatból megrendeléssé válás.

## 5. Üzleti modell

**Javaslat: havidíjas előfizetés**, opcionális egyszeri beállítási szolgáltatással.

Indoklás:
- A szolgáltatás folyamatos adatkezelést és működő emlékeztetőrendszert biztosít.
- A tárhely, karbantartás, biztonsági mentés és fejlesztés folyamatos költség.
- Az előfizetés kiszámíthatóbb ismétlődő bevételt teremthet.

### Kezdeti árazási hipotézis

| Csomag | Tervezett ár | Tervezett tartalom |
|---|---:|---|
| Próbaidőszak | 14 nap, ingyenes | Az alapfunkciók kipróbálása |
| Basic | 2 990 Ft/hó | Ügyfél- és ajánlatkövetés |
| Pro | 4 990 Ft/hó | Automatizált utánkövetés és részletes statisztikák |

Ezek nem végleges árak. Fizetési hajlandóságot célügyfél-interjúkkal és későbbi tesztekkel kell mérni. Az automatikus ügyfél-e-mail pontos csomagbesorolása még nyitott döntés.

## 6. Piacra lépési javaslat

Kezdetben a közvetlen megkeresés legyen az elsődleges csatorna. Ennek célja nemcsak az értékesítés, hanem a probléma és a fizetési hajlandóság validálása is.

Későbbi csatornák:
- Keresőoptimalizált tartalom olyan kifejezésekre, mint „ajánlatkövető program” és „ügyfél utánkövető rendszer”.
- Ajánlási rendszer, például sikeres ajánlás után egy hónap kedvezmény.

Fizetett hirdetések csak a termék és az üzenet validálása után javasoltak.

## 7. Költség- és erőforráskeret

A kezdeti tervezési keret legfeljebb 30 000 Ft. A korábbi terv heti 1–2 óra munkával számolt, de ez célérték, nem igazolt fejlesztési becslés. A tényleges időigényt az MVP elkészítése során kell mérni.

## 8. Fő kockázatok és feltételezések

- **Probléma–termék illeszkedés:** még igazolni kell, hogy a célvállalkozások számára elég fájdalmas és gyakori probléma az elmaradt utánkövetés.
- **Fizetési hajlandóság:** a 2 990–4 990 Ft/hó ársáv hipotézis.
- **Használat:** ha az adatbevitel túl hosszú, a vállalkozók visszatérhetnek a meglévő módszereikhez.
- **Megbízhatóság:** egy elmaradó emlékeztető csökkentheti a bizalmat.
- **Verseny:** az általános CRM-ek már kínálnak ügyfél- és ajánlatkövetést; a LeadPilotnak egyszerűbb, célzottabb munkafolyamatot kell adnia.

## 9. Következő üzleti döntések

1. A klímaszerelői célcsoport validálása.
2. Annak eldöntése, hogy az első verzió csak a vállalkozónak küldjön emlékeztetőt, automatikus ügyfél-e-mailt is küldjön, vagy mindkettőt tudja.
3. Mobilra optimalizált webalkalmazás megerősítése első platformként.
4. Az MVP funkcióinak és technikai architektúrájának véglegesítése.
