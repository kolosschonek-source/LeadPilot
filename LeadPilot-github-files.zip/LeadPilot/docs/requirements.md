# LeadPilot – Termékkövetelmények és MVP

## 1. Dokumentum státusza

Ez az első követelménytervezet a LeadPilot üzleti koncepciója alapján. Nem végleges specifikáció. A célcsoporttal folytatott interjúk és a technikai tervezés után pontosítandó.

## 2. Termékcél

A vállalkozó egyetlen egyszerű felületen tudja rögzíteni az érdeklődőket és ajánlatokat, áttekinteni a nyitott ügyeket, és megtudni, kivel kell ma kapcsolatba lépnie.

## 3. Elsődleges felhasználó

Kezdeti célcsoport-javaslat: magyarországi, 1–10 fős klímaszerelő vagy klímatelepítő vállalkozás tulajdonosa vagy munkatársa.

## 4. Fő felhasználói folyamat

1. A felhasználó létrehoz egy érdeklődőt.
2. Megadja az alapvető kapcsolatfelvételi adatokat és a kért szolgáltatást.
3. Rögzíti, hogy mikor küldte el az ajánlatot, és – ha ismert – annak értékét.
4. A rendszer a beállított idő elteltével utánkövetési teendőt jelez.
5. A felhasználó kapcsolatba lép az ügyféllel.
6. Rögzíti a kapcsolatfelvétel eredményét és a következő lépést.
7. A dashboard megmutatja a nyitott ajánlatokat és az aktuális teendőket.

## 5. Funkcionális követelmények

### Must-have – az MVP alapja

- **Ügyfél/érdeklődő létrehozása:** név és legalább egy elérhetőségi adat rögzíthető legyen.
- **Szolgáltatás leírása:** a vállalkozó röviden megadhassa, mire kértek ajánlatot.
- **Ajánlat dátuma:** rögzíthető legyen az ajánlat elküldésének dátuma.
- **Ajánlat státusza:** legalább nyitott, megnyert és elvesztett állapot.
- **Utánkövetési határidő:** az ajánlathoz tartozzon következő teendő dátuma.
- **Mai teendők:** külön lista mutassa az esedékes és lejárt utánkövetéseket.
- **Dashboard:** mutassa a nyitott ajánlatok és az esedékes teendők számát.
- **Szerkesztés:** a rögzített ügyfél- és ajánlatadatok módosíthatók legyenek.

### Should-have – ha az MVP keretébe belefér

- Ajánlati érték rögzítése és a nyitott ajánlatok összértéke.
- Egyszerű keresés és szűrés.
- Utánkövetési előzmények rögzítése.
- A felhasználó által módosítható emlékeztetési időköz.
- Reszponzív, mobilon kényelmes kezelőfelület.

### Későbbi fejlesztések

- Automatikus ügyfél-e-mail küldése.
- E-mail- és naptárintegráció.
- Részletes konverziós statisztikák.
- Több felhasználós csapatkezelés.
- Számlázó vagy más CRM-rendszer integrációja.

## 6. Nyitott termékdöntések

Ezeket nem szabad kész tényként kezelni:

1. **Utánkövetés módja:** csak belső emlékeztető; automatikus ügyfél-e-mail; vagy mindkettő.
2. **Kezdő célcsoport:** klímaszerelők; más szakipari vállalkozások; vagy szélesebb kisvállalkozói kör.
3. **Platform:** mobilra optimalizált webalkalmazás a javasolt első lépés; natív mobilalkalmazás nem része az első verziónak.
4. **Árazás:** a Basic 2 990 Ft/hó és Pro 4 990 Ft/hó csak tesztelendő hipotézis.
5. **Felhasználók száma:** az első verzió egy vállalkozás és egy felhasználó köré épüljön-e, vagy szükséges a több felhasználó.

## 7. Nem funkcionális követelmények

- **Megbízhatóság:** az esedékes teendők ne tűnjenek el és ne maradjanak észrevétlenül.
- **Használhatóság:** az új érdeklődő rögzítése kevés lépésből álljon.
- **Reszponzivitás:** telefonon és asztali böngészőben is használható legyen.
- **Adatvédelem:** csak a működéshez szükséges személyes adatokat kezelje; a hozzáférés és adatkezelés tervezésekor a vonatkozó adatvédelmi követelményeket külön át kell tekinteni.
- **Adatbiztonság:** hozzáférésvédelem és rendszeres mentés szükséges az éles használat előtt.

## 8. MVP elfogadási feltételek

Az első MVP akkor tekinthető kipróbálhatónak, ha egy tesztfelhasználó:
1. új érdeklődőt tud rögzíteni;
2. ajánlatot tud hozzá kapcsolni;
3. be tud állítani utánkövetési dátumot;
4. meg tudja nézni az esedékes teendőket;
5. módosítani tudja az ajánlat státuszát;
6. telefonon is végig tudja vinni ugyanezt a folyamatot.

## 9. Kizárás az első MVP-ből

A LeadPilot első verziója nem teljes CRM, nem számlázóprogram, nem projektmenedzsment-rendszer, és nem marketingautomatizációs platform. Ezeket csak validált igény esetén érdemes később mérlegelni.
