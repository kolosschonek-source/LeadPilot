# LeadPilot – Fejlesztési ütemterv

## Alapelv

A roadmap validációvezérelt: előbb ellenőrizzük a problémát és a fizetési hajlandóságot, utána építjük meg a minimális terméket. A szakaszok sorrendje javaslat; a pontos időtartam a rendelkezésre álló heti időtől és a technikai döntésektől függ.

## 0. szakasz – Repository és projektalapok

- [x] GitHub repository létrehozása.
- [ ] Dokumentáció feltöltése a repositoryba.
- [ ] Projektmappák és alap README rendezése.
- [ ] Fejlesztési feladatok és döntések követése GitHub Issues vagy Projects segítségével.

**Kilépési feltétel:** a projekt alapdokumentumai és döntési pontjai egy helyen elérhetők.

## 1. szakasz – Probléma- és célcsoport-validáció

- [ ] Legalább 5 klímaszerelő vagy klímatelepítő vállalkozás megkeresése.
- [ ] Megkérdezni, hogyan tartják nyilván az érdeklődőket és ajánlatokat.
- [ ] Felmérni, milyen gyakran marad el az utánkövetés.
- [ ] Megérteni, milyen megoldást használnak jelenleg.
- [ ] Megkérdezni, fizetnének-e egy ilyen rendszerért, és milyen ársávban.
- [ ] Eldönteni, hogy a célcsoport megfelelő-e.

**Kilépési feltétel:** dokumentált interjúk és megalapozott döntés a kezdő célcsoportról.

## 2. szakasz – MVP-specifikáció és technológiai tervezés

- [ ] A nyitott termékdöntések lezárása.
- [ ] MVP funkciólista véglegesítése.
- [ ] Felhasználói folyamatok és képernyővázlatok elkészítése.
- [ ] Frontend-, backend- és adatbázis-technológia kiválasztása.
- [ ] Bejelentkezés, adatvédelem és mentések megtervezése.

**Kilépési feltétel:** megvalósítható technikai terv és elfogadási feltételek.

## 3. szakasz – MVP-fejlesztés

Javasolt fejlesztési sorrend:
1. Alkalmazás alapstruktúrája és reszponzív felület.
2. Ügyfél/érdeklődő létrehozása, listázása és szerkesztése.
3. Ajánlat rögzítése és státuszkezelés.
4. Utánkövetési dátum és esedékes teendők listája.
5. Dashboard alapmutatói.
6. Hibakezelés és alapvető tesztek.

**Kilépési feltétel:** az MVP elfogadási feltételei teljesülnek tesztkörnyezetben.

## 4. szakasz – Pilot teszt

- [ ] 2–3 vállalkozással kipróbáltatni a rendszert.
- [ ] Megfigyelni, mennyi idő egy érdeklődő rögzítése.
- [ ] Visszajelzést gyűjteni a napi teendőlistáról.
- [ ] Hibákat és félreértéseket javítani.
- [ ] Megmérni, használják-e rendszeresen a rendszert.

**Kilépési feltétel:** a pilotfelhasználók a fő folyamatot önállóan végig tudják vinni, és a visszajelzések alapján nincs kritikus akadály.

## 5. szakasz – Fizetős indulás előkészítése

- [ ] Végleges árazás tesztelése.
- [ ] Próbaidőszak és előfizetési folyamat megtervezése.
- [ ] Adatkezelési és felhasználási dokumentumok előkészítése.
- [ ] Ügyféltámogatási folyamat kialakítása.
- [ ] Első ügyfelek megszerzése közvetlen megkereséssel.

**Kilépési feltétel:** a szolgáltatás biztonságosan és fenntartható módon kínálható fizető ügyfeleknek.

## Prioritási szabály

A fejlesztés során minden új ötletnél tegyük fel a kérdést: segít-e közvetlenül az érdeklődők és ajánlatok utánkövetésében? Ha nem, akkor valószínűleg nem része az MVP-nek.
