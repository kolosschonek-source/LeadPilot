# LeadPilot – Versenytárselemzés

## 1. A dokumentum célja és adatkorlátai

Ez a dokumentum a LeadPilot első versenytárskutatásának rendszerezett változata. A benne szereplő árak és értékelések a kutatási anyagban rögzített, **2026. november 15-i** állapotot tükrözik. A termékek árazása és funkciói változhatnak, ezért üzleti döntés vagy publikálás előtt minden adatot újra ellenőrizni kell.

A versenytársak felhasználói értékelése nem azonos az üzleti sikerrátával. A kutatás nem tartalmaz megbízható, összehasonlítható adatot a fizető ügyfelek megtartásáról, a próbaidőszak utáni konverzióról vagy a nyereségességről.

## 2. Vizsgált versenytársak

### Magyar szereplők

| Termék | Kutatásban rögzített ár | Megjegyzések |
|---|---|---|
| QlickCRM | Start 2 900 Ft; Medium 6 900 Ft; Pro 11 900 Ft / felhasználó / hó | Ügyféladatbázis, értékesítési folyamatok, emlékeztetők, ajánlatkezelés és automatizálás. |
| Pyn CRM | Free 0 Ft; Starter 4 990 Ft; Pro 14 990 Ft; Enterprise 29 990 Ft | Leadkezelés, értékesítési folyamatok, elakadt ajánlatok jelzése és AI-funkciók. |
| MiniCRM | Nyilvános listaár a kutatásban nem szerepelt | Ügyfélkezelés, értékesítési folyamatok, e-mail- és SMS-kampányok, utánkövetés; egyedi ajánlatkérés. |

### Nemzetközi szereplők

| Termék | Kutatásban rögzített ár / értékelés | Megjegyzések |
|---|---|---|
| Bigin by Zoho | Express 7 USD/hó; Premier 12 USD/hó, éves fizetéssel; Capterra 4,7/5, 744 értékelés | Egyszerű értékesítési folyamat, feladatok, emlékeztetők, mobilalkalmazás. |
| Pipedrive | Lite 14 USD; Growth 39 USD; Premium 59 USD; Ultimate 79 USD / felhasználó / hó, éves fizetéssel; Capterra 4,5/5, több mint 3 000 értékelés | Vizuális értékesítési folyamat és automatizálás. |
| HubSpot CRM | Ingyenes verzió; Starter 7 USD/felhasználó/hó éves fizetéssel; Capterra 4,5/5, több mint 4 400 értékelés | Széles CRM- és marketingfunkciók, sok integráció. |
| Jobber | Core kb. 29 USD/hó; Connect kb. 99 USD/hó egy felhasználóra, éves fizetéssel; G2 4,6/5, több mint 500 értékelés | Helyszíni szolgáltató vállalkozásoknak készült rendszer. |
| Housecall Pro | Alapcsomag 59 USD/hó éves vagy 79 USD/hó havi fizetéssel; Capterra 4,7/5, több mint 2 700 értékelés | Ügyfélkezelés, időpontfoglalás, ajánlatadás, számlázás és ügyfélkommunikáció. |

**Megjegyzés:** a fenti adatok a kiinduló kutatásból származnak, nem jelen idejű, függetlenül újraellenőrzött ár- vagy értékelési adatok.

## 3. Mit mondanak az értékelések – és mit nem?

A kutatásban szereplő értékelések a felhasználói elégedettség egy részét mutatják. Nem bizonyítják önmagukban a vállalkozás nyereségességét vagy a termék üzleti sikerét.

A kutatási anyagban rögzített példák:
- Bigin: 4,7/5 Capterra-értékelés, 744 értékelés.
- Pipedrive: 4,5/5 Capterra-értékelés, több mint 3 000 értékelés.
- HubSpot: 4,5/5 Capterra-értékelés, több mint 4 400 értékelés.
- Jobber: 4,6/5 G2-értékelés, több mint 500 értékelés.
- Housecall Pro: 4,7/5 Capterra-értékelés, több mint 2 700 értékelés.

A valódi üzleti sikerráta megállapításához többek között próbaidőszak-konverzióra, ügyfélmegtartásra, aktív használatra és bevételi adatokra lenne szükség. Ezek a kutatásban nem álltak rendelkezésre.

## 4. Visszatérő erősségek és problémák

A kiinduló kutatás a felhasználói visszajelzésekből és CRM-kutatásokból az alábbi mintákat emelte ki.

### A sikeres termékeknél fontosnak tűnő jellemzők

1. **Gyors tanulhatóság:** a vállalkozó rövid idő alatt értse meg a rendszert.
2. **Konkrét probléma megoldása:** a termék ne legyen funkcióhalmaz, hanem egy jól azonosítható munkafolyamatot javítson.
3. **Megbízhatóság:** az emlékeztetők és adatok kezelése következetesen működjön.
4. **Alacsony adminisztráció:** az érdeklődő rögzítése legyen gyors.
5. **Átlátható ár:** a kisvállalkozó értse, mit kap az előfizetésért.

### Kutatásban azonosított problémák és LeadPilot-válaszok

| Probléma | Lehetséges következmény | LeadPilot termékelv |
|---|---|---|
| Túl sok funkció | Nehéz kezelés | Szűk, utánkövetés-központú MVP |
| Bonyolult adatbevitel | A felhasználó nem rögzíti az érdeklődőket | Gyors, kevés mezős rögzítés |
| Drága vagy nehezen átlátható csomagok | Lemondás vagy belépési akadály | Egyszerű, átlátható árazás |
| Alapfunkciók fizetős csomagba zárása | Rossz ügyfélélmény | A fő utánkövetési folyamat legyen elérhető az alapcsomagban |
| Hibás vagy elmaradó értesítések | Elveszett érdeklődők | Megbízható emlékeztetők és tesztelés |
| Hiányos integrációk | Több manuális munka | E-mail- és naptárintegráció későbbi fejlesztési lehetőségként |
| Gyenge mobilos használat | Nehézkes helyszíni használat | Mobilra optimalizált felület |

Ezek általános termékfejlesztési tanulságok, nem mindegyik köthető egyetlen konkrét versenytárshoz. A kiinduló kutatás példaként a Bigin esetében a korlátozott automatizációt és integrációkat, a HubSpotnál a fizetős funkciók elhelyezését, a Housecall Pro esetében pedig egyes hibákat és zavaró felületi elemeket említett.

## 5. Stratégiai következtetés

A LeadPilotnak nem funkciószámban kell versenyeznie az általános CRM-ekkel. A lehetséges megkülönböztető tényező:
- célzott ajánlat- és érdeklődő-utánkövetés;
- gyors adatbevitel;
- egyértelmű napi teendőlista;
- megbízható emlékeztetők;
- egyszerű, mobilon is jól használható felület.

## 6. További kutatási feladatok

- A versenytársak aktuális árazásának és funkcióinak újraellenőrzése.
- Magyar célvállalkozások által ténylegesen használt rendszerek feltérképezése.
- Legalább öt potenciális klímaszerelő vállalkozás interjúja.
- A versenytársak próbaidőszakának kipróbálása, ha elérhető.
- A felhasználói értékelésekből származó problémák forrásainak és gyakoriságának ellenőrzése.
