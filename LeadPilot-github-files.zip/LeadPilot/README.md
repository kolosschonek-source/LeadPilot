# LeadPilot

**Smart Follow-up System for Small Businesses**

A LeadPilot célja, hogy a kis szolgáltató vállalkozások ne veszítsenek el érdeklődőket és kiküldött ajánlatokat az elmaradt utánkövetés miatt.

## Projektállapot

A projekt jelenleg üzleti tervezési és MVP-előkészítési szakaszban van. A célcsoport, az MVP pontos funkciói és a technikai architektúra még validálandó döntések.

## Dokumentáció

- [Üzleti terv](docs/business-plan.md)
- [Versenytárselemzés](docs/competitor-analysis.md)
- [Termékkövetelmények](docs/requirements.md)
- [Fejlesztési ütemterv](docs/roadmap.md)

## Alapkoncepció

- **Terméktípus:** micro-SaaS
- **Kezdő piac:** Magyarország
- **Elsődleges célcsoport-javaslat:** 1–10 fős klímaszerelő és klímatelepítő vállalkozások
- **Megoldandó probléma:** elfelejtett érdeklődők és ajánlatok
- **Üzleti modell-javaslat:** havidíjas előfizetés
- **Tervezett ársáv:** 2 990–4 990 Ft/hó
- **Platform-javaslat:** mobilra optimalizált webalkalmazás

A fenti célcsoport és árazás hipotézis, amelyet potenciális ügyfelekkel kell ellenőrizni.

## Következő üzleti mérföldkő

Legalább 5 potenciális célügyféllel beszélni, és ellenőrizni:
1. Milyen gyakran marad el náluk az ajánlatok utánkövetése?
2. Jelenleg hogyan tartják nyilván az érdeklődőket és ajánlatokat?
3. Milyen megoldásért és milyen áron fizetnének?
4. Melyik utánkövetési mód lenne számukra hasznosabb?

## Dokumentumok státusza

A dokumentumok a projekt első kutatási anyagából készültek. A versenytársak árai és értékelései a kutatásban rögzített, 2026. november 15-i állapotot tükrözik; indulás vagy üzleti döntés előtt újra ellenőrizendők.
